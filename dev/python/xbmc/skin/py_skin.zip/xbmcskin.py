# xbmcskin.py - v0.1 - Bitplane
# loads xbmc skins, in a crude kind of way.
# read skinningreadme.txt for details

import xbmcgui, xbmc
from xml.dom import minidom
import string, os

#
# This class is 
#
class XBMC_SKIN_CONTROL:
    def __init__(self,owner):
        self.options = {}
        self.control = None
        self.owner = owner

    def create(self):
        """
            internal:
            creates the control and adds it to the page
            assumes width/height etc are already set
            does not do navigation
        """
        # get generic stuff, position, type, etc
        t = string.lower(self.getoption("type"))
        
        x = int(self.getvalue(self.getoption("posx")))
        y = int(self.getvalue(self.getoption("posy")))
        c=None
        
        # 0 means auto (afaik)
        w = 0  
        h = 0  
        t1 = self.getoption("width")
        if t1 != "":
            w = int(self.getvalue(t1))
        t1 = self.getoption("height")
        if t1 != "":
            h = int(self.getvalue(t1))
        l = self.getoption("label")
        try:
            t1 = int(l)
            l = xbmc.getLocalizedString(t1)
        except:
            pass
        
        tx = self.getoption("texture")
        if tx != "":
            if os.path.exists(self.owner.path + tx):
                tx = self.owner.path + tx
                
        tx1 = self.getoption("texturefocus")
        if tx1 != "":
            if os.path.exists(self.owner.path + tx1):
                tx1 = self.owner.path + tx1
        tx2 = self.getoption("texturenofocus")
        if tx2 != "":
            if os.path.exists(self.owner.path + tx2):
                tx2 = self.owner.path + tx2
            
        ck   = self.getoption("colorkey")
        font = self.getoption("font")
        tcol = self.getoption("textcolor")
        
        c = None
        if t == "image":
            if ck == "":
                c = xbmcgui.ControlImage(x,y,w,h,tx)
            else:
                c = xbmcgui.ControlImage(x,y,w,h,tx,ck)

        if t == "button":
            if tx1 == "":
                c = xbmcgui.ControlButton(x,y,w,h,l)
            elif tx2 == "":
                c = xbmcgui.ControlButton(x,y,w,h,l,tx1)
            else:
                c = xbmcgui.ControlButton(x,y,w,h,l,tx1,tx2)

        if t == "fadelabel":
            c = xbmcgui.ControlFadeLabel(x,y,w,h,l,font,tcol)
        
        if t == "label":
            c = xbmcgui.ControlLabel(x,y,w,h,l,font,tcol)

        if t == "listcontrol":
            if tx1 == "":
                c = xbmcgui.ControlList(x,y,w,h)
            elif tx2 == "":
                c = xbmcgui.ControlList(x,y,w,h,tx1)
            else:
                c = xbmcgui.ControlList(x,y,w,h,tx1,tx2)

        if t == "textbox":
            c = xbmcgui.ControlTextBox(x,y,w,h,font,tcol)
            # c.setText()

        if c != None:
            # lists are acting funny. trying remove instead of hide
            t1 = self.owner.getoption("defaultgroup")
            if t1 == self.getoption("group") or self.getoption("group") == "":
                self.owner.addControl(c)
                
        self.control = c

    def getoption(self,stroption):
        """
            gets a setting from the controls options
            without raising an error if it doesnt exist (returns "")
        """
        x = ""
        try:
            x = self.options[stroption]
        except:
            pass
        if x == "-":
            x = ""
        return x

    def getvalue(self,strval):
        """
            internal: gets a value from an equation for x,y,width,height
        """
        r = str(strval)
        for x in self.owner.options:
            r = string.replace(r,"(" + str(x) + ")",str(self.owner.options[x]))
        try:
            return eval(r)
        except:
            return r
    

class XBMC_SKIN(xbmcgui.Window):
    def loadskin(self,strxmlfile):
        """
            loads the given skin file and creates all the controls
            then makes the default group ("") visible
            
            controls are listed in the XBMC_SKIN.controls dictionary
            window settings are listed in the XBMC_SKIN.options
        """
        # read the xml
        dom = minidom.parse(strxmlfile)

        # get the current path
        self.path = strxmlfile[0:strxmlfile.rfind("\\")+1]

        # set window options
        self.options = {}
        self.options["width"]  = self.getWidth()
        self.options["height"] = self.getHeight()
        self.setoptions(dom.getElementsByTagName("window")[0])

        # create the controls
        self.controls = {}
        self.activecontrol = None
        self.addcontrols(dom.getElementsByTagName("control"))
        
        dom.unlink()
        del dom

        # show the default group
        self.group = self.getoption("defaultgroup")
        self.showgroup(self.group)

    def getvalue(self,strval):
        """
            internal: gets a value from an equation for x,y,width,height
        """
        r = str(strval)
        for x in self.options:
            r = string.replace(r,"(" + str(x) + ")",str(self.options[x]))
        try:
            return eval(r)
        except:
            print "Possible skin error: problem evaluating", r
            return r

    def setoptions(self, n):
        """
            internal: loads the window options
            from the <window> section in the skin
            n = root window node
        """
        # add window settings
        for m in n.childNodes:
            if m.nodeType == 1:
                if string.lower(str(m.nodeName)) != "controls":
                    self.options[string.lower(str(m.nodeName))] = self.getvalue(m.childNodes[0].nodeValue)
    
    def addcontrols(self, nodes):
        """
            internal: adds the controls in the DOM nodes collection
        """
        # add the controls
        for n in nodes:
            me = XBMC_SKIN_CONTROL(self)
            for m in n.childNodes:
                if m.nodeType == 1:
                    if string.lower(str(m.nodeName)) == "id":
                        self.controls[str(m.childNodes[0].nodeValue)] = me
                    me.options[string.lower(str(m.nodeName))] = str(m.childNodes[0].nodeValue)
            me.create()

    def getoption(self,stroption):
        """
            gets an setting from the windows options
            without raising an error if it doesnt exist (returns "")
        """
        x = ""
        try:
            x = self.options[stroption]
        except:
            pass
        if x == "-":
            x = ""
        return x

    def showgroup(self, strgrp):
        """
            shows all controls that have group=strgroup, or group=""
            if strgrp is "", the window's default control is focused
            otherwise, the control with "default" set is focused
        """
        
        self.group = strgrp
        # lock the gui for speed
        xbmcgui.lock()
        
        # add/hide all the controls
        for id in self.controls:
            n = self.controls[id]
            m = n.getoption("group")
            try:
                if m == strgrp or m == "":
                    self.addControl(n.control)
                    #n.control.setVisible(True)
                else:
                    self.removeControl(n.control)
                    #n.control.setVisible(False)
            except:
                pass
                
        setdef = None
        # sort out the navigation
        for id in self.controls:
            n = self.controls[id]
            m = n.getoption("group")
            if m == strgrp or m == "":
                # this one is here, set its options
                x = n.getoption("onup")
                if x != "":
                    n.control.controlUp(self.controls[x].control)
                x = n.getoption("ondown")
                if x != "":
                    n.control.controlDown(self.controls[x].control)
                x = n.getoption("onleft")
                if x != "":
                    n.control.controlLeft(self.controls[x].control)
                x = n.getoption("onright")
                if x != "":
                    n.control.controlRight(self.controls[x].control)
                if n.getoption("default") != "":
                    setdef = n
        
        # unlock the gui
        xbmcgui.unlock()

        # set the default control
        if strgrp == "":
            if self.getoption("defaultcontrol") != "":
                self.setFocus(self.controls[self.getoption("defaultcontrol")].control)
        else:
            if setdef != None:
                self.setFocus(setdef.control)

    def getcontrolid(self,control):
        """
            returns the ID of the control from the xml,
            if it is in the skin's list
        """
        for i in self.controls:
            if self.controls[i].control is control:
                return str(i)
        return ""

