// Copyright (C) 2009 Gaz Davidson
// for copying permissions see readme.txt

#ifndef __C_ICO_LOADER_H_INCLUDED__
#define __C_ICO_LOADER_H_INCLUDED__

#include "IFileArchive.h"
#include "irrArray.h"
#include "IWriteFile.h"
#include "IReadFile.h"
#include "irrArray.h"

namespace irr
{
namespace video
{
	class IVideoDriver;
}
namespace io
{
	class IFileSystem;

#if defined(_MSC_VER) || defined(__BORLANDC__) || defined (__BCPLUSPLUS__) 
#	pragma pack( push, packing )
#	pragma pack( 1 )
#	define PACK_STRUCT
#elif defined( __GNUC__ )
#	define PACK_STRUCT	__attribute__((packed))
#else
#	error compiler not supported
#endif

	const u32 PNGMagicNumber = 0x474e5089;

	struct SIcoFileHeader
	{
		u16 reserved;     // 0
		u16 resourceType; // 1 for icon, 2 for cursor
		u16 itemCount;
	} PACK_STRUCT;

	struct SIconDetails
	{
		u8  width;       // width in pixels
		u8  height;      // height in pixels
		u8  colourCount; // only in paletted image, 0 for 24/32 bit
		u8  reserved;    // 0
		u16 planes;      // 1
		u16 bpp;         // 1, 4, 8, 24 or 32 bit
		u32 size;        // size of icon data including header
		u32 offset;      // position in the file (absolute)
	} PACK_STRUCT;

	// Icon data header is just a bitmap file header with some items
	// removed from the top. 
	struct SBitmapFileHeader
	{
		u16 Magic;                // "BM"
		u32 FileSize;             // 
		u32 Reserved;             // 0
		u32 BitmapDataOffset;     // becomes sizeof(SBitmapFileHeader)
		struct SIconDataHeader
		{
			u32 BitmapHeaderSize; // sizeof(SBitmapFileHeader)
			u32 Width;
			u32 Height;
			u16 Planes;
			u16 BPP;
			u32 Compression;
			u32 BitmapDataSize;   // Size of the bitmap data in bytes. This number must be rounded to the next 4 byte boundary.
			u32 PixelPerMeterX;
			u32 PixelPerMeterY;
			u32 UsedColors;
			u32 ImportantColors;
		} IconDataHeader;
	} PACK_STRUCT;

// Default alignment
#if defined(_MSC_VER) || defined(__BORLANDC__) || defined (__BCPLUSPLUS__) 
#	pragma pack( pop, packing )
#endif

#undef PACK_STRUCT


	class CArchiveLoaderICO : public IArchiveLoader
	{
	public:

		//! Constructor
		CArchiveLoaderICO(io::IFileSystem* fs, video::IVideoDriver* driver);

		//! Check if the file might be loaded by this class
		virtual bool isALoadableFileFormat(const path& filename) const;

		//! Check if the file might be loaded by this class
		virtual bool isALoadableFileFormat(io::IReadFile* file) const;

		//! Check to see if the loader can create archives of this type.
		virtual bool isALoadableFileFormat(E_FILE_ARCHIVE_TYPE fileType) const;

		//! Creates an archive from the filename
		virtual IFileArchive* createArchive(const path& filename, bool ignoreCase, bool ignorePaths) const;

		//! Creates an archive from the file
		virtual IFileArchive* createArchive(io::IReadFile* file, bool ignoreCase, bool ignorePaths) const;

	private:
		io::IFileSystem* FileSystem;
		video::IVideoDriver* VideoDriver;
	};



	class CIcoReader : public IFileArchive
	{
	public:

		//! constructor
		CIcoReader(io::IFileSystem* fs, video::IVideoDriver* driver, IReadFile* file, bool ignoreCase, bool ignorePaths);
		
		//! destructor
		virtual ~CIcoReader();

		//! Opens a file based on its name
		virtual IReadFile* createAndOpenFile(const path& filename);

		//! Opens a file based on its position.
		virtual IReadFile* createAndOpenFile(u32 index);

		//! Returns the complete file tree
		virtual const IFileList* getFileList() const;

		//! get the class Type
		virtual E_FILE_ARCHIVE_TYPE getType() const 
		{ 
			return E_FILE_ARCHIVE_TYPE(MAKE_IRR_ID('i', 'c', 'o', 0)); 
		}

	private:
		struct SIcoArchiveEntry
		{
			//! Complete details about the icon data
			SIconDetails details;

			//! True for PNG files, false for reconstructed TGA files
			bool isPNG;
		};

		u32 populateFileList();
		
		IReadFile* File;
		video::IVideoDriver* VideoDriver;
		IFileSystem* FileSystem;

		bool IgnoreCase;
		bool IgnorePaths;
		core::array<SIcoArchiveEntry> FileData;
		IFileList *FileList;

		io::path Base;
	};

	//! Provides write acess to an array as if it is a file.
	class CIcoMemoryReadWriteFile : public virtual IWriteFile, public virtual IReadFile
	{
	public:

		CIcoMemoryReadWriteFile(const fschar_t* filename=0);

		//! Reads an amount of bytes from the file.
		virtual s32 write(const void* buffer, u32 sizeToWrite);

		//! Changes position in file, returns true if successful.
		virtual bool seek(long finalPos, bool relativeMovement = false);

		//! Returns size of file.
		virtual long getSize() const;

		//! Reads an amount of bytes from the file.
		virtual s32 read(void* buffer, u32 sizeToRead);

		//! Returns the current position in the file.
		virtual long getPos() const;

		//! Returns name of file.
		virtual const io::path& getFileName() const;

		//! Returns file data as an array
		core::array<c8>& getData();

	private:

		core::array<c8> Data;
		io::path FileName;
		long Pos;
	};

} // namespace io
} // namespace irr

#endif // __C_ICO_LOADER_H_INCLUDED__
