#include <irrlicht.h>

#include "CIcoLoader.h"

using namespace irr;

#ifdef _IRR_WINDOWS_
#pragma comment(lib, "Irrlicht.lib")
#endif

int main()
{

	IrrlichtDevice *device =
		createDevice( video::EDT_OPENGL, core::dimension2d<u32>(800, 600), 32);

	if (!device)
		return 1;

	io::IFileSystem* fs = device->getFileSystem();
	video::IVideoDriver* driver = device->getVideoDriver();
	scene::ISceneManager* smgr = device->getSceneManager();
	gui::IGUIEnvironment* guienv = device->getGUIEnvironment();

	// create an instance of the loader and add it to the filesystem
	io::CArchiveLoaderICO* icoLoader = new io::CArchiveLoaderICO(fs, driver);
	fs->addArchiveLoader(icoLoader);

	// we created it with new, we are finished with it so we must drop it.
	icoLoader->drop(); 

	// now we can add an .ICO archive to the filesystem, in order to extract TGAs and PNGs from it
	//fs->addFileArchive("../../bin/Win32-VisualStudio/irrlicht.ico");
	fs->addFileArchive("bitplane.ico");

	// doing it this way looks inside the file before opening it
	//fs->addFileArchive("../../bin/Win32-VisualStudio/irrlicht.ico", true, true, io::E_FILE_ARCHIVE_TYPE(MAKE_IRR_ID('i', 'c', 'o', 0)));

	guienv->addImage(driver->getTexture("bitplane.ico.2.tga"), core::vector2di(0,0));

	while(device->run())
	{
		driver->beginScene(true, true, video::SColor(255,100,101,140));

		smgr->drawAll();
		guienv->drawAll();

		driver->endScene();
	}

	device->drop();

	return 0;
}
