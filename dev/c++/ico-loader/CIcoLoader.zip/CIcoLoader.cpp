// Copyright (C) 2009 Gaz Davidson
// for copying permissions see readme.txt

#include "CIcoLoader.h"

#include "IFileSystem.h"
#include "IVideoDriver.h"
#include "IWriteFile.h"


namespace irr
{
namespace io
{

//! Constructor
CArchiveLoaderICO::CArchiveLoaderICO(io::IFileSystem* fs, video::IVideoDriver *video)
: FileSystem(fs), VideoDriver(video)
{

}

//! returns true if the file maybe is able to be loaded by this class
//! based on the file extension (e.g. ".ico")
bool CArchiveLoaderICO::isALoadableFileFormat(const io::path& filename) const
{
	return core::hasFileExtension(filename, "ico", "cur");
}

//! Creates an archive from the filename
IFileArchive* CArchiveLoaderICO::createArchive(const io::path& filename, bool ignoreCase, bool ignorePaths) const
{
	IFileArchive *archive = 0;
	io::IReadFile* file = FileSystem->createAndOpenFile(filename);

	if (file)
	{
		archive = createArchive(file, ignoreCase, ignorePaths);
		file->drop();
	}

	return archive;
}

//! Check if the file might be loaded by this class
bool CArchiveLoaderICO::isALoadableFileFormat(io::IReadFile* file) const
{
	// remember file position
	long pos = file->getPos();
	file->seek(0);

	// read file header
	SIcoFileHeader header;
	memset(&header, 0, sizeof(SIcoFileHeader));
	file->read(&header, sizeof(SIcoFileHeader));

	bool ret =  (header.resourceType == 1 || header.resourceType == 2) // must be icon or cursor
	         && (header.reserved == 0)                                 // must be 0 
	         && (header.itemCount > 0);                                // must contain stuff

	// return to old position
	file->seek(pos);

	return ret;
}

//! Check if the file might be loaded by this class
bool CArchiveLoaderICO::isALoadableFileFormat(E_FILE_ARCHIVE_TYPE fileType) const
{
	return fileType == E_FILE_ARCHIVE_TYPE(MAKE_IRR_ID('i', 'c', 'o', 0));
}

//! creates/loads an archive from the file.
io::IFileArchive* CArchiveLoaderICO::createArchive(io::IReadFile* file, bool ignoreCase, bool ignorePaths) const
{
	IFileArchive *archive = 0;
	if (file)
	{
		file->seek(0);
		archive = new CIcoReader(FileSystem, VideoDriver, file, ignoreCase, ignorePaths);
	}
	return archive;
}


//! constructor
CIcoReader::CIcoReader(io::IFileSystem* fs, video::IVideoDriver* driver, IReadFile* file, bool ignoreCase, bool ignorePaths)
 : File(file), VideoDriver(driver), FileSystem(fs), IgnoreCase(ignoreCase), IgnorePaths(ignorePaths), FileList(0)
{
	#ifdef _DEBUG
	setDebugName("CIcoReader");
	#endif

	if (File)
	{
		File->grab();

		Base = File->getFileName();
		Base.replace('\\', '/');

		// fill the file list
		populateFileList();
	}
}	

//! destructor
CIcoReader::~CIcoReader()
{
	if (File)
		File->drop();
	if (FileList)
		FileList->drop();
}


const IFileList* CIcoReader::getFileList() const
{
	return FileList;
}

//! opens a file by file name
IReadFile* CIcoReader::createAndOpenFile(const io::path& filename)
{
	if (FileList)
	{
		s32 index = FileList->findFile(filename);

		if (index != -1)
			return createAndOpenFile(index);
	}

	return 0;
}

//! opens a file by index
IReadFile* CIcoReader::createAndOpenFile(u32 listIndex)
{
	if (listIndex >= FileData.size())
		return 0;

	u32 dataIndex = FileList->getID(listIndex);

	// if this is a PNG file, we create a limit read file
	if (FileData[dataIndex].isPNG)
	{
		return FileSystem->createLimitReadFile(FileList->getFileName(listIndex), 
			File, FileData[dataIndex].details.offset, FileData[dataIndex].details.size);
	}
	else
	{
		// otherwise it is a bitmap.
		c8* buf = 0;
		SBitmapFileHeader header;

		header.Magic = 0x4d42; // 0x4d42 = 19778 = BM
		header.FileSize = FileData[dataIndex].details.size + sizeof(SBitmapFileHeader);
		header.Reserved = 0;

		File->seek(FileData[dataIndex].details.offset);
		File->read(&header.IconDataHeader, sizeof(SBitmapFileHeader::SIconDataHeader));

		// skip palette
		header.BitmapDataOffset = sizeof(SBitmapFileHeader) + (1 << header.IconDataHeader.BPP)*4;
		u32 stride           = ((header.IconDataHeader.Width*header.IconDataHeader.BPP) / 32 + 
		                       ((header.IconDataHeader.Width*header.IconDataHeader.BPP % 32) == 0 ? 0 : 1)) * 4;

		// we have two sets of data in here, divide height by 2
		header.IconDataHeader.Height /= 2;

		// read in the file data...
		buf = new c8[header.FileSize];
		memcpy(buf, &header, sizeof(SBitmapFileHeader));
		File->read(buf + sizeof(SBitmapFileHeader), (1 << header.IconDataHeader.BPP)*4 + stride*header.IconDataHeader.Height);

		// turn it into a memory file and open it
		IReadFile* tmpFile = FileSystem->createMemoryReadFile(buf, header.FileSize, "#temp_icon_XOR.bmp", false);
		video::IImage* imgXOR = VideoDriver->createImageFromFile(tmpFile);
		tmpFile->drop();

		// if there is an 8 bit alpha channel present, we can ignore the 1-bit one.
		// if not, we need it
		if (header.IconDataHeader.BPP < 32)
		{

			// now prepare the 1-bit image...
			u32 oneBitWidthBytes = ((header.IconDataHeader.Width / 32 +
								   ((header.IconDataHeader.Width % 32) == 0 ? 0 : 1)) ) * 4;
			//u32 oneBitDataStart  = header.BitmapDataOffset;//  +  stride * header.IconDataHeader.Height;
			header.IconDataHeader.BPP = 1;
			header.BitmapDataOffset = sizeof(SBitmapFileHeader);
			memcpy(buf, &header, sizeof(SBitmapFileHeader));
			File->read(buf + header.BitmapDataOffset, oneBitWidthBytes * header.IconDataHeader.Height);

			tmpFile = FileSystem->createMemoryReadFile(buf, header.FileSize, "#temp_icon_AND.bmp", false);

			// load the image
			video::IImage* imgAND = VideoDriver->createImageFromFile(tmpFile);
			tmpFile->drop();

			// copy the alpha channel from the 1-bit image...
			for (u32 y=0; y<header.IconDataHeader.Height; ++y)
				for (u32 x=0; x<header.IconDataHeader.Width; ++x)
				{
					video::SColor c = imgXOR->getPixel(x,y);
					u32 a = imgAND->getPixel(x,y).getGreen();
					c.setAlpha(255-a);
					imgXOR->setPixel(x,y,c);
				}
		
			imgAND->drop();
		}

		// now write the image into memory as a TGA file
		io::CIcoMemoryReadWriteFile* outFile = new CIcoMemoryReadWriteFile(FileList->getFileName(listIndex).c_str());
		VideoDriver->writeImageToFile(imgXOR, outFile);

		// clean up
		imgXOR->drop();
		delete [] buf;
		
		return outFile;
	}
}

u32 CIcoReader::populateFileList()
{
	// save old position and move to start of file
	long pos = File->getPos();
	File->seek(0);

	// create file list
	if (FileList)
		FileList->drop();
	FileList = FileSystem->createEmptyFileList(Base, IgnoreCase, IgnorePaths);

	// clear file data array
	FileData.clear();

	// read file header
	SIcoFileHeader header;
	memset(&header, 0, sizeof(SIcoFileHeader));
	File->read(&header, sizeof(SIcoFileHeader));

	SIcoArchiveEntry entry;

	// name is ArchiveName.ext.index[a].format
	io::path baseFileName = Base;
	core::deletePathFromFilename(baseFileName);
	baseFileName.append(".");
	if (IgnoreCase)
		baseFileName.make_lower();

	// read icons from the file
	for (u32 i=0; i < header.itemCount; ++i)
	{
		io::path fileName;

		// read entry from file
		File->read(&entry.details, sizeof(SIconDetails));

		long oldPos = File->getPos();

		fileName = baseFileName;
		fileName.append(io::path(i));
		
		File->seek(entry.details.offset);

		// is it a PNG file?
		u32 magic = 0;
		File->read(&magic, 4);

		if (magic == PNGMagicNumber)
		{
			entry.isPNG = true;
			fileName.append(".png");
			FileList->addItem(fileName, entry.details.size, false, FileData.size());
			FileData.push_back(entry);
		}
		else if (magic == 40)
		{
			entry.isPNG = false;
			fileName.append(".tga");
			FileList->addItem(fileName, entry.details.size, false, FileData.size());			
			FileData.push_back(entry);
		}
		// else ignore this item
		File->seek(oldPos);
	}

	File->seek(pos);

	return FileData.size();
}


CIcoMemoryReadWriteFile::CIcoMemoryReadWriteFile(const fschar_t* filename) 
:  Data(), FileName(filename), Pos(0)
{
}


s32 CIcoMemoryReadWriteFile::write(const void* buffer, u32 sizeToWrite)
{
	// no point in writing 0 bytes
	if (sizeToWrite < 1)
		return 0;

	// expand size
	if (Pos + sizeToWrite > Data.size())
		Data.set_used(Pos+sizeToWrite);

	// copy data
	memcpy( (void*) &Data[Pos], buffer, (size_t) sizeToWrite);

	Pos += sizeToWrite;

	return sizeToWrite;
	
}

bool CIcoMemoryReadWriteFile::seek(long finalPos, bool relativeMovement)
{
	if (relativeMovement)
	{
		if (finalPos + Pos < 0)
			return 0;
		else
			Pos += finalPos;
	}
	else
	{
		Pos = finalPos;
	}

	if (Pos > (s32)Data.size())
		Data.set_used(Pos+1);

	return true;

}

const io::path& CIcoMemoryReadWriteFile::getFileName() const
{
	return FileName;
}

long CIcoMemoryReadWriteFile::getPos() const
{
	return Pos;
}

core::array<c8>& CIcoMemoryReadWriteFile::getData()
{
	return Data;
}


long CIcoMemoryReadWriteFile::getSize() const
{
	return Data.size();
}


s32 CIcoMemoryReadWriteFile::read(void* buffer, u32 sizeToRead)
{
	// cant read past the end
	if (Pos + sizeToRead >= Data.size())
		sizeToRead = Data.size() - Pos;

	// cant read 0 bytes
	if (!sizeToRead)
		return 0;

	// copy data
	memcpy( buffer, (void*) &Data[Pos], (size_t) sizeToRead);
	
	Pos += sizeToRead;

	return sizeToRead;
}



} // namespace io
} // namespace irr

