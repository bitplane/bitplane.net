Jetpac by Gaz Davidson - http://bitplane.net


compiling:

source code is in media.zip. 
You'll need the Irrlicht Engine to compile it- http://irrlicht.sourceforge.net/
To compile for linux or OSX, you'll have to change EDT_DIRECT3D9 to EDT_OPENGL


Legal ramble:

1) This game is no way affiliated with or endorsed by Microsoft/Rare or whoever owns 
the Jetpac games nowadays. This is just a tribute :)

2) The ArialB font was generated from Microsoft's Arial Black, so I can't give that
away, it's not mine. 
