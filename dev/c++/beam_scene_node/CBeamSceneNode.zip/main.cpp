#include <irrlicht.h>
#include <iostream>


#include "CBeamSceneNode.h"

using namespace irr;

#ifdef _MSC_VER
#pragma comment(lib, "Irrlicht.lib")
#endif


int main()
{
	IrrlichtDevice *device = createDevice(video::EDT_OPENGL,
			core::dimension2d<u32>(640, 480), 16, false);
		
	device->setWindowCaption(L"Beam Node - Irrlicht Engine");

	video::IVideoDriver* driver = device->getVideoDriver();
	scene::ISceneManager* smgr = device->getSceneManager();

	smgr->addCameraSceneNodeFPS();

	scene::CBeamSceneNode *myNode =
		new scene::CBeamSceneNode(smgr->getRootSceneNode(), smgr, 666, 
				core::vector3df(50,0,0), core::vector3df(0,20,300), 10);

	video::ITexture* tex = driver->getTexture("beam.png");

	//driver->makeColorKeyTexture(tex, core::vector2di(0,0));

	myNode->setMaterialType(video::EMT_TRANSPARENT_ALPHA_CHANNEL);
	myNode->setMaterialTexture(0, tex);


	scene::ISceneNodeAnimator* anim = 
		smgr->createRotationAnimator(core::vector3df(0.8f, 0, 0.8f));

	if(anim)
	{
		myNode->addAnimator(anim);
		anim->drop();
		anim = 0;
	}

	myNode->drop();
	myNode = 0;

	u32 frames=0;
	while(device->run())
		if (device->isWindowFocused())
	{
		driver->beginScene(true, true, video::SColor(0,10,10,100));

		smgr->drawAll();

		driver->endScene();
		if (++frames==100)
		{
			core::stringw str = L"Irrlicht Engine [";
			str += driver->getName();
			str += L"] FPS: ";
			str += (s32)driver->getFPS();

			device->setWindowCaption(str.c_str());
			frames=0;
		}
	}

	device->drop();
	
	return 0;
}
