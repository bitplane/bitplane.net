
#include <stdio.h>
#include <alloca.h>


void erm(int n);

char version[]="$VER: 1.00 Gareth Davidson Jan 99";

char erms[][30]=

{
"0 OK",
"1 NEXT without FOR",
"2 Variable not found",
"3 Subscript wrong",
"4 Out of memory",
"5 Out of screen",
"6 Number too big",
"7 RETURN without GOSUB",
"8 End of file",
"9 STOP statement",
"A Invalid argument",
"B Integer out of range",
"C Nonsense in BASIC",
"D BREAK - CONT repeats",
"E Out of DATA",
"F Invalid file name",
"G No room for line",
"H STOP in INPUT",
"I FOR without NEXT",
"J Invalid I/O device",
"K Invalid colour",
"L BREAK into program",
"M RAMTOP no good",
"N Statement lost",
"O Invalid stream",
"P FN without DEF",
"Q Parameter error",
"R Tape loading error"
};


struct thing
{
char name[50];
int type;
int index;
struct thing *last;
struct thing *next;
struct thing *yes;
struct thing *no;
};

main()
{
 struct thing *first,*current, *swap;
 int number=0;
 int x;
 char c;

 /* allocate some animals */

 if ((first=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;first->index=number;
 if ((current=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;current->index=number;
 if ((swap=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;swap->index=number;

 strcpy (first->name,"Does it live under water?");
 first->type=0;
 first->yes=current;
 first->no =swap;
 first->next=current;
 first->last=first;

 strcpy (current->name,"a seahorse");
 strcpy (swap->name,"a bird");
 current->type=1;
 current->last=first;
 current->next=swap;
 current->yes=NULL;
 current->no =NULL;

 swap->type=1;
 swap->yes=NULL;
 swap->no =NULL;
 swap->last=current;


 /* now for some veggies */

 if ((current=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;current->index=number;
 swap->next=current;


 strcpy (current->name,"Does it grow under ground?");
 current->type=0;
 current->last=swap;

 if ((swap=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;swap->index=number;
 current->next=swap;
 current->yes=swap;

 strcpy (swap->name,"a potatoe");
 swap->type=1;
 swap->yes=NULL;
 swap->no =NULL;
 swap->last=current;

 if ((current=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;current->index=number;
 swap->last->no=current;
 swap->next=current;

 strcpy (current->name,"a tree");
 current->last=swap;
 current->type=1;
 current->yes=NULL;
 current->no=NULL;

 /* And Minerals */

 swap=current;

 if ((current=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;current->index=number;
 swap->next=current;


 strcpy (current->name,"Is it worth lots of money?");
 current->type=0;
 current->last=swap;

 if ((swap=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;swap->index=number;
 current->next=swap;
 current->yes=swap;

 strcpy (swap->name,"diamonds");
 swap->type=1;
 swap->yes=NULL;
 swap->no =NULL;
 swap->last=current;

 if ((current=(struct thing*)malloc(sizeof(struct thing)))==NULL) erm(4);
 number++;current->index=number;
 swap->last->no=current;
 swap->next=current;

 strcpy (current->name,"coal");
 current->last=swap;
 current->type=1;
 current->yes=NULL;
 current->no=NULL;

 current->next=NULL;


 printf("Welcome to Animal, Vegtable, Mineral\n");


 begin:

 printf("Think of an Animal, Vegtable or Mineral,\nand I'll try to guess what it is!\n");
 printf("\n\nSo then... Is it an Animal, Vegetable or a Mineral?(a/v/m)");


 ask:

 fflush(stdin);
 scanf("%c",&c);
 if (c!='a'&&c!='v'&&c!='m')
 {

 printf("\n%s 0:1\nEither a,v or m!:",erms[10]);
 goto ask;

 }

 if (c=='a') current=first;
 if (c=='v') current=first->next->next->next;
 if (c=='m') current=first->next->next->next->next->next->next;


 /* ask the questions! */

 while (current->type==0)
 {
  printf("%s(y/n)",&current->name);

  quizz:

  fflush(stdin);
  scanf("%c",&c);

  if (c!='y'&&c!='n')
  {
   printf("\n%s 0:1\nPlease answer yes or no.(y/n)",erms[10]);
   goto quizz;
  }

  if (c=='y') current=current->yes;
  else current=current->no;

 }

 /* is this the answer? */

 printf("\nIn that case it must be %s.\n",&current->name);
 printf("Am I right?(y/n)");

 quiz2:

 fflush(stdin);
 scanf("%c",c);

 if (c!='y'&&c!='n')
 {
  printf("\n%s 0:1\nJust give me a yes or no answer!(y/n)",erm[10]);
  goto quiz2;
 }

 if (c=='y')
 {
  printf("Yeeess! Got one right! Teach me more!\n");
  goto begin;
 }

 printf("Then it must be time for me to increase my memory banks!\n");
 printf("What was the thing you were thinking of?\neg)some grass\n:");

 fflush(stdin);


 quitout:
 erm(0);
}

void erm(n)
{

 printf("%s 0:1\n",erms[n]);
 if (n!=0) n=20;
 exit (n);
}
