
#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <string.h>
#include <math.h>

#include "C:\tclite\bgi\rotate.h"
#include "c:\tclite\bgi\file.h"
#include "c:\tclite\bgi\letters.h"

main(int ac,char *as[])
{
 struct _3dcoords rotation,offset;
 struct coords middle;
 struct letter *first,*current;
 FILE *input;
 float aspect =0.002,
	zoom   =0.1;
 char c;
 int gdriver = DETECT, gmode, errorcode;
 offset.x  =offset.y  =offset.z     = 0;
 rotation.x=rotation.y=rotation.z   = 0;

 if (ac!=2)
 {
	printf("What is up with you people?\n");
	printf("Dont you read the documentation?\n");
	printf("\nusage:\n\tTEXTROT <STRING>\n");
	return(20);
 }

 initgraph(&gdriver, &gmode, "");
 errorcode = graphresult();
 if (errorcode != grOk)  /* an error occurred */
 {
   printf("We've got a crappy GFX error\n");
   printf("And it looks like: %s\n", grapherrormsg(errorcode));
   printf("Press any key to halt:");
   getch();
   exit(1); /* terminate with an error code */
 }
 middle.x=getmaxx()/2,middle.y=getmaxy()/2;

 if ( (input = fopen("letters.dat", "rt") )  == NULL)
 {
   printf("Gutted! Can't load letters.dat!\n");
   return(20);
 }

 first=current=loadletters(input);

 fclose (input);

 setfillstyle(1,15);

 while (c!='q')
 {
  c=getch();
  cleardevice();

  if (c=='z') rotation.z+=0.2;
  if (c=='x') rotation.z-=0.2;
  if (c=='c') rotation.x+=0.2;
  if (c=='v') rotation.x-=0.2;
  if (c=='b') rotation.y+=0.2;
  if (c=='n') rotation.y-=0.2;

  if (c=='i') zoom      +=0.1;
  if (c=='o') zoom      -=0.1;
  if (zoom<=0) zoom=0.01;
  if (c=='1') offset.x+=20;
  if (c=='2') offset.x-=20;
  if (c=='3') offset.y+=20;
  if (c=='4') offset.y-=20;

  if (c=='9') aspect+=.0005;
  if (c=='0') aspect-=.0005;

  if (c=='r')
  {
   cleardevice();
   current=current->next;
   if (current==NULL) current=first;
   rotation.x=rotation.y=rotation.z=0;
  }


  put3dtext  (as[1],
	      first,
	      &offset,
	      &rotation,
	      &middle,
	      zoom,
	      aspect);

 }
 closegraph();
}