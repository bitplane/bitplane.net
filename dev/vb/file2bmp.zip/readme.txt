File2BMP

The speed of this thing is stupid, perhaps I should have written it in C. 
Well it does the job of converting a file in to a bitmap, and was written in about the same time it took to write this readme.

It XORS the file (that's the slow bit), so it should get stuff through most mail blockers.

