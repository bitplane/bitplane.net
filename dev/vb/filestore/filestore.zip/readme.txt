Filestore.mdb, Gareth Davidson 2001 - Public Domain
