<?
include('head.php');

function updateUser()
{

	global $userid;
	global $pagebody;
	global $dbusr;
	global $dbpw;
	global $database;


	$diagonal = $_GET['d'];
	$aspectw  = $_GET['w'];
	$aspecth  = $_GET['h'];

	// make sure data is valid

	if (!is_numeric($userid))
	{
		$pagebody .= 'userid is not valid. dont fuck with me, h4x0r.';
		return;
	}

	if (!is_numeric($diagonal) || !is_numeric($aspectw) || !is_numeric($aspecth) )
	{
		$pagebody .= 'Width, height and diagonal size must be numbers!';
		return;
	}

	if ($aspectw <= 0 || $aspecth <= 0 || $diagonal <= 0)
	{
		$pagebody .= 'aspect and diagonal values cannot be <= 0.';
		return;
	}

	// work out aspect ratio from length of sides.

	$aspectratio = $aspectw / $aspecth;

	// work out length of edges in inches (pythag)

	$diagonalunits = sqrt(1 + ($aspectratio*$aspectratio));

	$inchh = $diagonal / $diagonalunits;
	$inchw = $inchh * $aspectratio;

	$sql = 'UPDATE `user` SET `w` = \'' . $inchw . '\', '
		. '`h` = \'' . $inchh . '\''
		. ' WHERE `id` = ' . $userid . ' LIMIT 1;';

	mysql_connect(localhost,$dbusr,$dbpw);
	@mysql_select_db($database) or die("Unable to connect to database");

	$result=mysql_query($sql);

	if(!$result)
		die("unable to update record in database");

	mysql_close();

	$_SESSION['w'] = $inchw;
	$_SESSION['h'] = $inchh;

	$pagebody .= "saved your settings, redirecting you to the page you came from... $sql";
}


updateUser();

include('foot.php');

?>