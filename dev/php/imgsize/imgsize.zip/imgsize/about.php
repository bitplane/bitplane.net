<?
if (!$noinclude)
	include('head.php');

$pagebody .= '<center><h2>What is ImgSize.com?</h2>'
		. '<p>ImgSize.com is a handy resource for anyone wanting to display an image in its actual size, '
		. 'whether you\'re selling something on ebay or just want to show off your latest toy, ImgSize '
		. 'can show the world how large or small something is on-screen, in its real size.'
		. '</p>'
		. '<h2>How does it work?</h2>'
		. '<p>I keep a record of how large your monitor is and compare it to how many pixels wide and '
		. 'tall your desktop is. When a user posts an image, I ask for it\'s real size in inches. '
		. 'When someone views an image, I work out what the size should be in pixels and stretch or shrink '
		. 'the image on screen. It\'s that simple!</p>'
		. '<h2>Why do I need cookies enabled?</h2>'
		. '<p>I give you a cookie so I don\'t have to ask you for the size of your monitor each '
		. 'time you visit the site. I only store 4 things about you in the database: a number '
		. 'which identifies you as a user, the width and height of your screen, and the'
		. 'number of times you\'ve accessed the site. I\'m not interested in anything else.</p>'
		. '<h2>Why do I need Javascript enabled?</h2>'
		. '<p>I need to use Javascript to determine the size of your screen in pixels, and to '
		. 'resize the picture. If you disable javascript disabled, it won\'t work.</p>'
		. '<h2>Who runs this site?</h2>'
		. '<p>I (Gaz Davidson) do, you can contact me <a href=\'mailto:gaz@imgsize.com\'>here</a> if you like.</p>';

if ($googlead)
{
	$pagebody .= '<h2>Why adverts, are you only in it for the money?</h2>'
		. '<p>If you don\'t like them, I won\'t cry if you block them. '
		. 'If the site makes enough money to pay my hosting costs, I\'ll remove them!</p>';
}
else
{
	$pagebody .= '<h2>Where did the adverts go?</h2>'
		. '<p>Awww is the page all empty without the google ads? I said I\'d remove them when they\'d '
		. 'paid my hosting costs, they\'ll be back again shortly</p>';
}
$pagebody .= '</center>';


if (!$noinclude)
	include('foot.php'); 

?>