<?

$pageheader .= "<title>ImgSize.com | " . $pagetitle . "</title>\n";
$pageheader .= "<meta name=\"description\" content=\"" . $metadesc     . "\"/>\n";
$pageheader .= "<meta name=\"keywords\"    content=\"" . $metakeywords . "\"/>\n";

echo "$pageheader";
echo "$pagebody";

echo "<div id='headerbar'><h1>$headerbar</h1>\n<br/><center>&copy; ImgSize.com 2007</center></div>\n";

echo '<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script><script type="text/javascript">_uacct = "UA-1777801-1";urchinTracker();</script>';

echo "</body>\n</html>\n";

?>