<?

// make sure we dont start a session for bots

$bots = array(
'(.*googlebot.*)',    // google
'(.*slurp.*)',        // yahoo slurp (also altavista)
'(.*msnbot.*)',       // msn search
'(.*teoma.*)',        // ask / teoma
'(.*ia_archiver.*)',  // internet archive
'(.*gigabot.*)',      // gigablast crawler
'(.*w3c_validator.*)' // w3c validation service
);

$pattern = '/' . implode('|', $bots) . '/i';

if (preg_match($pattern, $_SERVER['HTTP_USER_AGENT']) != True)
{
  session_start();
  $bot = False;
}
else
{
  $bot = True;
}

$pageheader = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml">'
            . '<head>';

$dbusr		= "imgsize_rw";
$dbpw		= "imgzzzsIze_123";
$database	= "imgsize_db";

$userid		= $_SESSION['uid'];
$user 		= $_COOKIE["uid"];
$screenwidth	= $_SESSION['w'];
$screenheight	= $_SESSION['h'];
$visits		= 0;

if (!is_numeric($user) || $user==0)
	$user = '';

if (!is_numeric($userid) || $userid==0)
	$userid = '';


if ($bot == False)
{

	if ($userid == '')
	{

		if ($user == '')
		{

			// add a record to the database

			$sql = 'INSERT INTO `user` (`id`, `w`, `h`, `visits`) '
				. 'VALUES (NULL, \'0\', \'0\', \'1\');';

			mysql_connect(localhost,$dbusr,$dbpw);
			@mysql_select_db($database) or die("Unable to connect to database");

			$result=mysql_query($sql);

			if(!$result)
				die("unable to create record");

			// save in session cookie and variables
			$user = mysql_insert_id();

			mysql_close();

			$userid = $user;
			$_SESSION['uid'] = $user;
			$screenwidth = $_SESSION['w'] = '0';
			$screenheight = $_SESSION['h'] = '0';
			

			// create new user cookie
			setcookie("uid", $user, time()+315360000);
		}
		else
		{
			// get user from the database
			$sql = "select * from user where user.id='" . $user . "' limit 1;";
			mysql_connect(localhost,$dbusr,$dbpw);
			@mysql_select_db($database) or die("Unable to connect to database");

			$result=mysql_query($sql);

			if(!$result)
				die("unable to read database");

			$screenwidth	= mysql_result($result,0,'w');
			$_SESSION['w']	= $screenwidth;
			$screenheight	= mysql_result($result,0,'h');
			$_SESSION['h']	= $screenheight;

			// increment access count

			$visits		= mysql_result($result,0,'visits') + 1;

			$sql = 'UPDATE `user` SET `visits` = \'' . $visits . '\''
				. ' WHERE `id` = ' . $user . ' LIMIT 1;';

			$result = mysql_query($sql);

			if(!$result)
				die("unable to update user");

			mysql_close();

			$_SESSION['uid'] = $user;
			// update cookie
			setcookie("uid", $user, time()+315360000);
			$userid = $user;
		}

		if ($userid == '')
		{
			die('something went wrong. corrupted cookie?');
		}

	}

}


$headerbar 	= '<a href="new.php">New Image</a> | '
		. '<a href="/?mode=random">Random</a> | '
		. '<a href="about.php">About</a>';

$metakeywords	= "image, size";
$metadesc	= "Shows the real size of any image on the Internet";

$pageheader	.= '<link rel="stylesheet" type="text/css" href="style.css"/>'
		.  '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>'
		.  '<script language="JavaScript" src="funcs.js"></script>';


$adstart = '<!-- google_ad_section_start -->';
$adignorestart = '<!-- google_ad_section_start(weight=ignore) -->';
$adend   = '<!-- google_ad_section_end -->';
$googlead = '<script type="text/javascript">google_ad_client = "pub-5117854341927396"; google_alternate_color = "0000FF"; google_ad_width = 728; google_ad_height = 90; google_ad_format = "728x90_as"; google_ad_type = "text"; google_ad_channel ="2700452599"; google_color_border = "FFFFFF"; google_color_bg = "FFFFFF"; google_color_link = "000000"; google_color_url = "666666"; google_color_text = "666666"; </script><script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>';

$pagebody   =  '</head><body>'
            .  '<div id="headerbar">'
            .  '<p align="center">'
            .  '<center><a href="/"><img src="images/imgsize.png" alt="ImgSize" border="0"/></a><br/>'
            .  $googlead
            .  '</center></p>'
            .  '<h1>' . $headerbar . '</h1></div>';	

?>