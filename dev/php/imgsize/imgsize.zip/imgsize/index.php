<?

include('head.php');

$imgno = $_GET['i'];

if (!is_numeric($imgno))
	$imgno = '';

if ($bot == False && ( $screenwidth == 0 || $screenheight == 0 || $_GET['mode'] == 'reset'))
{

	$pagetitle = "Please set your monitor size for user #$user $screenwidth, $screenheight ";

	$pagebody .= '<form name="newuser" action="javascript:location.href=OnSubmit()">'
		. 'Before we can show you images, we\'ll need some information about the size of your screen.<br/><br/>'
		. 'What is your monitor size?<br/>'

		. '<select name="monitorSize" onChange="OnMonitorSizeChange()">'
		. '<option value="14"/> 14"'
		. '<option value="15"/> 15"'
		. '<option value="15.4"/> 15.4"'
		. '<option value="17"/> 17"'
		. '<option value="19"/> 19"'
		. '<option value="21"/> 21"'
		. '<option value="-1"/> Other'
		. '</select>'
		. '<div id="customSize" style="visibility: hidden">'
		. '<input type="text" size="4" name="customSizeVal" value="17"/> Inches'
		. '<layer></layer>'
		. '</div>'
		. 'And its aspect ratio<br/>'
		. '<select name="monitorAspect" onChange="OnMonitorAspectChange()">'
		. '<option value="4:3"/> 4:3 (VGA/SVGA/PAL)'
		. '<option value="16:9"/> 16:9 Widescreen (HD, WVGA)'
		. '<option value="3:2"/> 3:2 (NTSC)'
		. '<option value="16:10"/> 16:10'
		. '<option value="5:4"/> 5:4 (SXVGA)'
		. '<option value="-1"/> Other / Unknown'
		. '</select>'
		. '<div id="customAspect" style="visibility: hidden">'
		. '<input type="text" size="4" name="customAspectW" value="4"/> Wide, '
		. '<input type="text" size="4" name="customAspectH" value="3"/> Tall <br/>'
		. 'Note: default values are in pixels, they should really be in inches or millimeters'
		. '<layer></layer>'
		. '</div>'
		. '<input type="hidden" name="redirect" value="' . $imgno . '"/><input type="submit" value="Save"/>'
		. '</form>';
}
else
{

	if ($imgno == '' && $_GET['mode'] != 'random')
	{
		$noinclude = 1;
		include('new.php');
	}
	else
	{

		$result = '';
		mysql_connect(localhost,$dbusr,$dbpw);
		@mysql_select_db($database) or die("Unable to connect to database");

		if ($_GET['mode'] == 'random')
		{
			$result = mysql_query( "SELECT * FROM `images` WHERE id >= (SELECT FLOOR( MAX(id) * RAND()) FROM `images` ) ORDER BY id LIMIT 1;" );
		}
		else
		{

			$sql = "select * from images where images.id='$imgno' limit 1;";
	
			$result=mysql_query($sql);
		}

		if(!$result || mysql_num_rows($result) != 1)
		{
			mysql_close();		
			$pagebody .= 'couldn\'t retrieve image information';
		}
		else
		{

			$imageurl = mysql_result($result,0,'url');
			$imgw = mysql_result($result,0,'w');
			$imgh = mysql_result($result,0,'h');
			$imgtitle = mysql_result($result,0,'name');

			mysql_close();

			$pagetitle .= $imgtitle;

			$pagebody .= '<center>' . $adstart . ' <h2>' . $imgtitle . '</h2>' . $adend
				. $adignorestart
				. '<img name="img" src="' . $imageurl . '" width="0" height="0" onload="resizeImage(\'img\',' . $screenwidth . ',' . $screenheight . ','. $imgw .',' . $imgh . ')"/><br/>'
				. '<center>Displaying Image in actual size (' . $imgw . '" x ' . $imgh . '"). We currently think your screen is '.$screenwidth.' inches wide and '.$screenheight.' inches tall.<br/>'
				. 'If this is incorrect, you can change it <a href="/?mode=reset">here</a>.'
				. $adend . '</center>';

		}

	}


}

include('foot.php'); 

?>