<?

if (!$noinclude)
	include('head.php');


$newname = addslashes(htmlspecialchars($_POST['name']));
$newurl = addslashes(htmlspecialchars($_POST['url']));
$neww = $_POST['w'];
$newh = $_POST['h'];

if ($newname && $newurl && is_numeric($neww) && is_numeric($newh))
{
	$sql = "INSERT INTO `images` (`id`, `w`, `h`, `name`, `url`) "
		. "VALUES (NULL, '$neww', '$newh', '$newname', '$newurl');";


	mysql_connect(localhost,$dbusr,$dbpw);
	@mysql_select_db($database) or die("Unable to connect to database");

	$result=mysql_query($sql);

	if(!$result)
		die("unable to create record".$sql);

	// save in session cookie and variables
	$newid = mysql_insert_id();

	mysql_close();

	

	$pagetitle .= 'Added: '.$newname;

	$pagebody .= '<center>';
	$pagebody .= '<h2>Image added</h2>'
			. '<p>You can view your image here:</p>'
			. "<a href='/?i=$newid'>http://imgsize.com/?i=$newid</a></center>";

}
else
{
	$pagetitle .= 'Adding an image';
	$pagebody .= '<center>';
	$pagebody .= '<h2>Add an Image</h2>'
			. '<form name="newimage" action="new.php" method="post"> '
			. '<p>Upload your image to somewhere like <a href="http://imageshack.us" target="_blank"/>ImageShack</a> '
			. 'or your personal web space, then paste a link to it here:</p><input name="url">'
			. '<p>Now give it a meaningful title, maximum of 50 characters</p><input type="text" name="name">'
			. '<p>And the width and height of the image in inches</p>Width: <input type="text" name="w"/> '
			. 'Height: <input type="text" name="h"/>'
			. '<br/><input type="submit" value="Submit"/>'
			. '</form>';

	$pagebody .= '</center>';
}


if (!$noinclude)
	include('foot.php'); 

?>