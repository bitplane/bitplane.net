var browserType;
var w2mm;
var h2mm;
var inch2mm = 0.393700787;

if (document.layers) {browserType = "nn4"}
if (document.all) {browserType = "ie"}
if (window.navigator.userAgent.toLowerCase().match("gecko")) {
   browserType= "gecko"
}


function hide(val) {
  if (browserType == "gecko" )
     document.poppedLayer = 
         eval('document.getElementById(\''+val+'\')');
  else if (browserType == "ie")
     document.poppedLayer = 
        eval('document.all[\''+val+'\']');
  else
     document.poppedLayer =   
        eval('document.layers[\'`'+val+'\']');
  document.poppedLayer.style.visibility = "hidden";
}

function show(val) {
  if (browserType == "gecko" )
     document.poppedLayer = 
         eval('document.getElementById(\''+val+'\')');
  else if (browserType == "ie")
     document.poppedLayer = 
         eval('document.all[\''+val+'\']');
  else
     document.poppedLayer = 
         eval('document.layers[\'`'+val+'\']');
  document.poppedLayer.style.visibility = "visible";
}

function OnMonitorSizeChange()
{
	if (window.document.newuser.monitorSize.value == '-1')
		show('customSize');
	else
		hide('customSize');
}

function OnMonitorAspectChange()
{
	if (window.document.newuser.monitorAspect.value == '-1')
	{
		window.document.newuser.customAspectW.value = screen.width;
		window.document.newuser.customAspectH.value = screen.height;
		show('customAspect');
	}
	else
		hide('customAspect');
}

function OnSubmit()
{
	var d;
	var w;
	var h;
	var r="";
	var ret="setuser.php?"

	if (window.document.newuser.monitorSize.value == '-1')
		d = window.document.newuser.customSizeVal.value;
	else
		d = window.document.newuser.monitorSize.value;

	if (window.document.newuser.monitorAspect.value == '-1')
	{
		w = window.document.newuser.customAspectW.value;
		h = window.document.newuser.customAspectH.value;
	}
	else
	{
		var arr = window.document.newuser.monitorAspect.value.split(":");
		w = arr[0];
		h = arr[1];
	}

	if (window.document.newuser.redirect)
	{
		r = window.document.newuser.redirect.value;
	}

	ret += "d=" + d + "&w=" + w + "&h="+ h;

	if (r != "")
		ret += "&r=" + r;

	return ret;
}

function resizeImage(name, sw, sh, rw, rh)
{

	w2 = (screen.width/sw)*rw;
	h2 = (screen.height/sh)*rh;

	eval("document."+name+".width="+w2);
	eval("document."+name+".height="+h2);
}
